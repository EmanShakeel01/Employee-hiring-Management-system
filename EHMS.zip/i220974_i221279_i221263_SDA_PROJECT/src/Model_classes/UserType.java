package Model_classes;

public enum UserType {
    RECRUITER,
    APPLICANT,
    HR
}
